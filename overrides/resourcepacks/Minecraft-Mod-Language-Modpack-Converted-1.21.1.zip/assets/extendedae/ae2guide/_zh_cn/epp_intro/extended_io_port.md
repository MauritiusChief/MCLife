---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME扩展IO端口
    icon: extendedae:ex_io_port
categories:
- extended devices
item_ids:
- extendedae:ex_io_port
---

# ME扩展IO端口

<Row gap="20">
<BlockImage id="extendedae:ex_io_port" p:powered="true" scale="8"></BlockImage>
</Row>

ME扩展IO端口的工作速度是普通<ItemLink id="ae2:io_port" />的8倍。

它的升级卡槽位数也多于普通的IO端口。
