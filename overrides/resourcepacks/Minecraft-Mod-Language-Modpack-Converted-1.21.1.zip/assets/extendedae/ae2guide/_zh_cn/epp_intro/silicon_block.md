---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: 硅块
  icon: extendedae:silicon_block
categories:
  - extended foundation
item_ids:
  - extendedae:silicon_block
---

# 硅块

<Row>
<BlockImage id="extendedae:silicon_block" scale="8"></BlockImage>
</Row>

用于存储<ItemLink id="ae2:silicon" />的方块。
