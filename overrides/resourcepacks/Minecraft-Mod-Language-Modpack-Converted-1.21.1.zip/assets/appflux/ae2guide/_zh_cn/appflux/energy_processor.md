---
navigation:
  parent: appflux/appflux-index.md
  title: 能量处理器
  icon: appflux:energy_processor
categories:
- flux materials
item_ids:
- appflux:energy_processor
- appflux:printed_energy_processor
- appflux:energy_processor_press
---

# 能量处理器

<Row>
<ItemImage id="appflux:energy_processor" scale="4"></ItemImage>
<ItemImage id="appflux:energy_processor_press" scale="4"></ItemImage>
<ItemImage id="appflux:printed_energy_processor" scale="4"></ItemImage>
</Row>

能量处理器可让能量在ME网络中自由流动。所有能量管理设备都需能量处理器来引导能量。
