---
navigation:
    title: 应用通量
    position: 70
---

# 在元件里存储能量！

应用通量（Applied Flux）可让AE系统管理你的能量储备。

## 通量元件
<CategoryIndex category="flux cells"></CategoryIndex>

## 材料
<CategoryIndex category="flux materials"></CategoryIndex>

## 通量访问点
<CategoryIndex category="flux accessor"></CategoryIndex>

## 技巧
<CategoryIndex category="flux tricks"></CategoryIndex>
