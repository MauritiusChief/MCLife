---
navigation:
  parent: appflux/appflux-index.md
  title: 感应卡
  icon: appflux:induction_card
categories:
- flux accessor
item_ids:
- appflux:induction_card
---

# 感应卡

<Row>
<ItemImage id="appflux:induction_card" scale="4"></ItemImage>
</Row>

感应卡可将<ItemLink id="ae2:pattern_provider" />和<ItemLink id="ae2:interface" />变为<ItemLink id="appflux:flux_accessor" />，方便输入和输出能量。
