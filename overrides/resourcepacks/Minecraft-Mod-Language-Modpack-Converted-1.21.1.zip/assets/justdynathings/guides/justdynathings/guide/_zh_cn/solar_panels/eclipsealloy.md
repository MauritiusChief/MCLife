---
navigation:
  title: 蚀空合金太阳能板
  icon: "justdynathings:eclipse_alloy_solar_panel"
  position : 4
  parent: justdynathings:solar_panels.md
item_ids:
  - justdynathings:eclipse_alloy_solar_panel
---

# 蚀空合金太阳能板

会生产Forge能量（Forge Energy）的太阳能板。

FE生产速率：**11520**

**条件：**
- 无条件

**增益：**
- 邻近的太阳能板会增加产能速率
- 处于高Y坐标或低Y坐标处可增加产能速率，中等Y坐标处则减少

<BlockImage id="justdynathings:eclipse_alloy_solar_panel" scale="4.0"/>

<RecipeFor id="justdynathings:eclipse_alloy_solar_panel" />