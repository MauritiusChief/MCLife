---
navigation:
  title: 黑洞
  icon: "justdynathings:blackhole"
  position : 5
  parent: justdynathings:other.md
item_ids:
  - justdynathings:blackhole
---

# 黑洞

更常被称作*万用垃圾桶*。

关闭其清除功能之后，就可用作极大容量流体和能量存储器具，而且占地面积很小！

<BlockImage id="justdynathings:blackhole" scale="4.0"/>

<RecipeFor id="justdynathings:blackhole" />